package com.example.medicinetracker.models

data class UploadResponse(
    val imageUrl: String,
    val medicines: List<String>
)