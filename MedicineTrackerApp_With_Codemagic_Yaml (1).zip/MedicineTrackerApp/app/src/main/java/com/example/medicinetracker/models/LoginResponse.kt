package com.example.medicinetracker.models

data class LoginResponse(
    val token: String,
    val user: User
)

data class User(
    val _id: String,
    val name: String,
    val email: String
)