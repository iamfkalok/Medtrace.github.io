package com.example.medicinetracker.activities

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import com.example.medicinetracker.R
import com.example.medicinetracker.models.Pharmacy
import com.example.medicinetracker.network.RetrofitClient
import com.example.medicinetracker.adapters.PharmacyAdapter
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class PharmacyActivity : AppCompatActivity(), OnMapReadyCallback {
    private lateinit var map: GoogleMap
    private lateinit var recyclerView: RecyclerView
    private var userLat = 0.0
    private var userLng = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pharmacy)

        recyclerView = findViewById(R.id.pharmacyRecyclerView)
        val mapFragment = supportFragmentManager.findFragmentById(R.id.mapFragment) as SupportMapFragment
        mapFragment.getMapAsync(this)

        val fusedLocationProvider = LocationServices.getFusedLocationProviderClient(this)
        fusedLocationProvider.lastLocation.addOnSuccessListener {
            if (it != null) {
                userLat = it.latitude
                userLng = it.longitude
                fetchPharmacies("Paracetamol")
            }
        }
    }

    private fun fetchPharmacies(medicine: String) {
        RetrofitClient.api.searchPharmacies(medicine, userLat, userLng).enqueue(object :
            Callback<List<Pharmacy>> {
            override fun onResponse(call: Call<List<Pharmacy>>, response: Response<List<Pharmacy>>) {
                if (response.isSuccessful) {
                    val pharmacies = response.body() ?: emptyList()
                    recyclerView.adapter = PharmacyAdapter(pharmacies)
                    plotMarkersOnMap(pharmacies)
                }
            }

            override fun onFailure(call: Call<List<Pharmacy>>, t: Throwable) {
                Toast.makeText(this@PharmacyActivity, "Failed: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun plotMarkersOnMap(pharmacies: List<Pharmacy>) {
        for (pharmacy in pharmacies) {
            val pos = LatLng(pharmacy.latitude, pharmacy.longitude)
            map.addMarker(MarkerOptions().position(pos).title("${pharmacy.name} - ₹${pharmacy.price}"))
        }
        map.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(userLat, userLng), 12f))
    }

    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap
    }
}