package com.example.medicinetracker.models

data class Pharmacy(
    val _id: String,
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val price: Double
)