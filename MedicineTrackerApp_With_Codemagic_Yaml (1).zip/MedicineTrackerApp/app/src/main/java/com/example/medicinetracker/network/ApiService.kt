package com.example.medicinetracker.network

import com.example.medicinetracker.models.LoginResponse
import com.example.medicinetracker.models.UploadResponse
import okhttp3.MultipartBody
import retrofit2.Call
import retrofit2.http.*

interface ApiService {
    @POST("auth/login")
    fun login(@Body credentials: Map<String, String>): Call<LoginResponse>

    @Multipart
    @POST("prescriptions/upload")
    fun uploadPrescription(@Part image: MultipartBody.Part): Call<UploadResponse>
}